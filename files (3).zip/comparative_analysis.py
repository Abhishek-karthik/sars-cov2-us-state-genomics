import seaborn as sns
import matplotlib.pyplot as plt
from Bio import AlignIO

states = ['california', 'new_york', 'texas']

# Function to calculate pairwise similarity
def calculate_similarity(align):
    similarity_matrix = []
    for seq1 in align:
        row = []
        for seq2 in align:
            similarity = sum(a == b for a, b in zip(seq1, seq2)) / len(seq1)
            row.append(similarity)
        similarity_matrix.append(row)
    return similarity_matrix

# Load and analyze alignments for each state
for state in states:
    align_mafft = AlignIO.read(f'aligned_{state}_mafft.fasta', 'fasta')
    align_prank = AlignIO.read(f'aligned_{state}_prank.best.fas', 'fasta')

    similarity_mafft = calculate_similarity(align_mafft)
    similarity_prank = calculate_similarity(align_prank)

    # Visualize differences using heatmaps
    sns.heatmap(similarity_mafft, cmap='viridis')
    plt.title(f'Pairwise Similarity (MAFFT) - {state.capitalize()}')
    plt.show()

    sns.heatmap(similarity_prank, cmap='viridis')
    plt.title(f'Pairwise Similarity (PRANK) - {state.capitalize()}')
    plt.show()