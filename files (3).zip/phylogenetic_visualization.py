from ete3 import Tree, TreeStyle

states = ['california', 'new_york', 'texas']

# Define a simple tree style
ts = TreeStyle()
ts.show_leaf_name = True

# Load and visualize the phylogenetic tree for each state
for state in states:
    tree_mafft = Tree(f'tree_{state}_mafft.nwk')
    tree_prank = Tree(f'tree_{state}_prank.nwk')

    print(f'Phylogenetic Tree (MAFFT) - {state.capitalize()}')
    tree_mafft.show(tree_style=ts)

    print(f'Phylogenetic Tree (PRANK) - {state.capitalize()}')
    tree_prank.show(tree_style=ts)