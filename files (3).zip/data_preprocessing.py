import pandas as pd

# Load the dataset
df = pd.read_csv('your_dataset.csv')

# Filter and clean data for specified states
states = ['California', 'New York', 'Texas']
filtered_df = df[df['location'].apply(lambda x: any(state in x for state in states))]
filtered_df = filtered_df.dropna(subset=['Nucleotide Sequence'])
filtered_df['Nucleotide Sequence'] = filtered_df['Nucleotide Sequence'].str.replace(r'[^ATCG]', '')

# Save sequences to FASTA files for each state
for state in states:
    state_df = filtered_df[filtered_df['location'].str.contains(state)]
    with open(f'{state.lower()}_sequences.fasta', 'w') as f:
        for index, row in state_df.iterrows():
            f.write(f">{row['Sequence ID']}\n{row['Nucleotide Sequence']}\n")