#!/bin/bash

# Install MAFFT and PRANK if not already installed
sudo apt-get install mafft prank

# Run MAFFT and PRANK for each state
for state in california new_york texas
do
    mafft --auto ${state}_sequences.fasta > aligned_${state}_mafft.fasta
    prank -d=${state}_sequences.fasta -o=aligned_${state}_prank
done