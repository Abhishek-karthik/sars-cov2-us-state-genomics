#!/bin/bash

# Install FastTree if not already installed
sudo apt-get install fasttree

# Construct phylogenetic tree for each state
for state in california new_york texas
do
    FastTree -nt aligned_${state}_mafft.fasta > tree_${state}_mafft.nwk
    FastTree -nt aligned_${state}_prank.best.fas > tree_${state}_prank.nwk
done