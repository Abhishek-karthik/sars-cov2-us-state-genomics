#!/bin/bash

# Install FastTree if not already installed
sudo apt-get install fasttree

# Construct phylogenetic tree
FastTree -nt aligned_mafft.fasta > tree_mafft.nwk
FastTree -nt aligned_prank.best.fas > tree_prank.nwk