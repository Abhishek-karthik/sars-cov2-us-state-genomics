#!/bin/bash

# Install MAFFT and PRANK if not already installed
sudo apt-get install mafft prank

# Run MAFFT
mafft --auto sequences.fasta > aligned_mafft.fasta

# Run PRANK
prank -d=sequences.fasta -o=aligned_prank