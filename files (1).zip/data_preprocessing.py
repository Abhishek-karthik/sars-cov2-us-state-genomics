import pandas as pd

# Load the dataset
df = pd.read_csv('your_dataset.csv')

# Filter and clean data
df = df.dropna(subset=['Nucleotide Sequence'])
df['Nucleotide Sequence'] = df['Nucleotide Sequence'].str.replace(r'[^ATCG]', '')

# Extract relevant columns
sequences = df[['Sequence ID', 'Nucleotide Sequence', 'location']]

# Save sequences to a FASTA file
with open('sequences.fasta', 'w') as f:
    for index, row in sequences.iterrows():
        f.write(f">{row['Sequence ID']}\n{row['Nucleotide Sequence']}\n")