from ete3 import Tree, TreeStyle

# Load and visualize the phylogenetic tree
tree_mafft = Tree('tree_mafft.nwk')
tree_prank = Tree('tree_prank.nwk')

# Define a simple tree style
ts = TreeStyle()
ts.show_leaf_name = True

# Render the tree
tree_mafft.show(tree_style=ts)
tree_prank.show(tree_style=ts)