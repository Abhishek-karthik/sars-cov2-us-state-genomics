import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from Bio import AlignIO

# Load aligned sequences
align_mafft = AlignIO.read('aligned_mafft.fasta', 'fasta')
align_prank = AlignIO.read('aligned_prank.best.fas', 'fasta')

# Calculate pairwise similarity (example for MAFFT)
def calculate_similarity(align):
    similarity_matrix = []
    for seq1 in align:
        row = []
        for seq2 in align:
            similarity = sum(a == b for a, b in zip(seq1, seq2)) / len(seq1)
            row.append(similarity)
        similarity_matrix.append(row)
    return similarity_matrix

similarity_mafft = calculate_similarity(align_mafft)
similarity_prank = calculate_similarity(align_prank)

# Visualize differences
sns.heatmap(similarity_mafft, cmap='viridis')
plt.title('Pairwise Similarity (MAFFT)')
plt.show()

sns.heatmap(similarity_prank, cmap='viridis')
plt.title('Pairwise Similarity (PRANK)')
plt.show()